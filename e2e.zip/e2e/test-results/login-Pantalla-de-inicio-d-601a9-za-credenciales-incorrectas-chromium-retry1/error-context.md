# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: login.spec.js >> Pantalla de inicio de sesión >> rechaza credenciales incorrectas
- Location: tests\login.spec.js:35:3

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByLabel('Dirección de correo electrónico')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]:
    - heading "Sign in to your account" [level=2] [ref=e5]
    - paragraph [ref=e6]:
      - text: Don't have an account yet?
      - button "Sign Up" [ref=e7] [cursor=pointer]
  - generic [ref=e10]:
    - generic [ref=e11]:
      - generic [ref=e12]: Email Address
      - textbox "Email Address" [ref=e13]:
        - /placeholder: you@example.com
    - generic [ref=e14]:
      - generic [ref=e15]: Password
      - textbox "Password" [ref=e16]:
        - /placeholder: ••••••••
    - button "Sign In" [ref=e18] [cursor=pointer]
```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | 
  3  | const EMAIL = process.env.TEST_EMAIL;
  4  | const PASSWORD = process.env.TEST_PASSWORD;
  5  | 
  6  | // Selectores basados en los textos visibles de la pantalla de login
  7  | const emailInput = (page) => page.getByLabel('Dirección de correo electrónico');
  8  | const passwordInput = (page) => page.getByLabel('Contraseña');
  9  | const submitButton = (page) => page.getByRole('button', { name: 'Iniciar sesión' });
  10 | 
  11 | test.describe('Pantalla de inicio de sesión', () => {
  12 |   test.beforeEach(async ({ page }) => {
  13 |     await page.goto('/');
  14 |   });
  15 | 
  16 |   test('muestra el formulario de login', async ({ page }) => {
  17 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  18 |     await expect(emailInput(page)).toBeVisible();
  19 |     await expect(passwordInput(page)).toBeVisible();
  20 |     await expect(submitButton(page)).toBeEnabled();
  21 |   });
  22 | 
  23 |   test('el enlace de registro lleva a la página de registro', async ({ page }) => {
  24 |     await page.getByText(/Sign Up/i).click();
  25 |     await expect(page).not.toHaveURL(/Sign In/i);
  26 |     await expect(emailInput(page)).toBeVisible();
  27 |   });
  28 | 
  29 |   test('no permite enviar el formulario vacío', async ({ page }) => {
  30 |     await submitButton(page).click();
  31 |     // Sigue en la misma pantalla de login
  32 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  33 |   });
  34 | 
  35 |   test('rechaza credenciales incorrectas', async ({ page }) => {
> 36 |     await emailInput(page).fill('no-existe@ejemplo.com');
     |                            ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  37 |     await passwordInput(page).fill('contraseña-incorrecta');
  38 |     await submitButton(page).click();
  39 | 
  40 |     // No debe entrar: el título de login sigue visible
  41 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  42 |   });
  43 | 
  44 |   test('inicia sesión con credenciales válidas', async ({ page }) => {
  45 |     test.skip(!EMAIL || !PASSWORD, 'Define TEST_EMAIL y TEST_PASSWORD en .env');
  46 | 
  47 |     await emailInput(page).fill(EMAIL);
  48 |     await passwordInput(page).fill(PASSWORD);
  49 |     await submitButton(page).click();
  50 | 
  51 |     // Al entrar, el formulario de login desaparece
  52 |     await expect(page.getByText(/Sign in to your account/i)).toBeHidden();
  53 |   });
  54 | });
  55 | 
```