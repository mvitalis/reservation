# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: login.spec.js >> Pantalla de inicio de sesión >> el enlace de registro lleva a la página de registro
- Location: tests\login.spec.js:23:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Dirección de correo electrónico')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByLabel('Dirección de correo electrónico') with timeout 5000ms
  - waiting for getByLabel('Dirección de correo electrónico')

```

```yaml
- heading "Create your business account" [level=2]
- paragraph:
  - text: Already have an account?
  - button "Sign In"
- text: PayPal Subscription checkout failed. Please try again. Select Your Plan
- heading "Starter" [level=3]
- text: Free
- paragraph: Essential booking features
- list:
  - listitem: • Up to 3 Services
  - listitem: • Standard URL
- heading "Pro" [level=3]
- text: $9.99/mo
- paragraph: Advanced features for growing businesses
- list:
  - listitem: • Unlimited Services
  - listitem: • Custom Booking URL
  - listitem: • SMS Reminders
- heading "Business" [level=3]
- text: $24.99/mo
- paragraph: Full suite for multi-location teams
- list:
  - listitem: • Everything in Pro
  - listitem: • Multiple Locations
  - listitem: • Priority Support
- text: Full Name
- textbox "Jane Doe"
- text: Business Name
- textbox "ByteFix Repairs"
- text: Email Address
- textbox "Email Address":
  - /placeholder: you@example.com
- text: Password
- textbox "Password":
  - /placeholder: ••••••••
- paragraph: "Pay via PayPal to complete subscription, or skip payment to test registration:"
- text: Or
- button "Create Pro Account (Skip Payment)" [disabled]
```

# Test source

```ts
  1  | const { test, expect } = require('@playwright/test');
  2  | 
  3  | const EMAIL = process.env.TEST_EMAIL;
  4  | const PASSWORD = process.env.TEST_PASSWORD;
  5  | 
  6  | // Selectores basados en los textos visibles de la pantalla de login
  7  | const emailInput = (page) => page.getByLabel('Dirección de correo electrónico');
  8  | const passwordInput = (page) => page.getByLabel('Contraseña');
  9  | const submitButton = (page) => page.getByRole('button', { name: 'Iniciar sesión' });
  10 | 
  11 | test.describe('Pantalla de inicio de sesión', () => {
  12 |   test.beforeEach(async ({ page }) => {
  13 |     await page.goto('/');
  14 |   });
  15 | 
  16 |   test('muestra el formulario de login', async ({ page }) => {
  17 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  18 |     await expect(emailInput(page)).toBeVisible();
  19 |     await expect(passwordInput(page)).toBeVisible();
  20 |     await expect(submitButton(page)).toBeEnabled();
  21 |   });
  22 | 
  23 |   test('el enlace de registro lleva a la página de registro', async ({ page }) => {
  24 |     await page.getByText(/Sign Up/i).click();
  25 |     await expect(page).not.toHaveURL(/Sign In/i);
> 26 |     await expect(emailInput(page)).toBeVisible();
     |                                    ^ Error: expect(locator).toBeVisible() failed
  27 |   });
  28 | 
  29 |   test('no permite enviar el formulario vacío', async ({ page }) => {
  30 |     await submitButton(page).click();
  31 |     // Sigue en la misma pantalla de login
  32 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  33 |   });
  34 | 
  35 |   test('rechaza credenciales incorrectas', async ({ page }) => {
  36 |     await emailInput(page).fill('no-existe@ejemplo.com');
  37 |     await passwordInput(page).fill('contraseña-incorrecta');
  38 |     await submitButton(page).click();
  39 | 
  40 |     // No debe entrar: el título de login sigue visible
  41 |     await expect(page.getByText(/Sign in to your account/i)).toBeVisible();
  42 |   });
  43 | 
  44 |   test('inicia sesión con credenciales válidas', async ({ page }) => {
  45 |     test.skip(!EMAIL || !PASSWORD, 'Define TEST_EMAIL y TEST_PASSWORD en .env');
  46 | 
  47 |     await emailInput(page).fill(EMAIL);
  48 |     await passwordInput(page).fill(PASSWORD);
  49 |     await submitButton(page).click();
  50 | 
  51 |     // Al entrar, el formulario de login desaparece
  52 |     await expect(page.getByText(/Sign in to your account/i)).toBeHidden();
  53 |   });
  54 | });
  55 | 
```